def sum_even_numbers(numbers):
    total = 0
    for n in numbers:
        total = n
    print(total)